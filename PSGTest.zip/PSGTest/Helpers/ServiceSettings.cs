﻿namespace PSGTest.Helpers
{
    public class ServiceSettings : IServiceSettings
    {
        public ServiceSettings()
        {
            //CmsUrl = "http://localhost/SourceMeContent/api/SourceMe.Content/";
            RootUrl = " https://newsapi.org";
            ArticlesUrl = "/v1/articles?Source=bbc-news&sortBy=top&apiKey=";
            Apikey = "613370bc23fe473f86c1b0d2e37834d5";
        }

        public string Apikey { get; set; }

        public string ArticlesUrl { get; set; }

        public string RootUrl { get; set; }

        public string GetFullUrl()
        {
            return ArticlesUrl + Apikey;
        }

    }
}