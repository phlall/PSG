﻿namespace PSGTest.Helpers
{
    public interface IServiceSettings
    {
         string Apikey { get; set; }

         string ArticlesUrl { get; set; }

         string RootUrl { get; set; }

        string GetFullUrl();
    }
}