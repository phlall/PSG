﻿using System.Data.Entity;

namespace PSGTest.DataLayer
{
    public class BaseContext<TContext> : DbContext where TContext : DbContext
    {
        static BaseContext()
        {
            Database.SetInitializer<TContext>(null);
        }

        protected BaseContext(string connString)
            : base(connString)
        { }

        protected BaseContext() : base("name=DefaultConnection")
        {
        }

    }
}
