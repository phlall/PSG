﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using Ninject;
using PSGTest.Models;

namespace PSGTest.DataLayer
{
    public class ArticleRepository : IArticleRepository
    {
        private IUnitOfWork _uow;
        readonly ArticleContext context;
        public ArticleRepository(IUnitOfWork uow)
        {
            _uow = uow;
            context = uow.Context as ArticleContext;
        }

        public void Dispose()
        {
            context.Dispose();
        }

        public void Insert(Article article)
        {
            var headLine = context.Headlines.Include("Articles").FirstOrDefault(x => x.Id == article.HeadLineId);
            if (headLine == null)
            {
                headLine = new Headline
                {
                    Id = article.HeadLineId,
                    Source = "PSG BBC Test",
                    Articles = new List<Article>()
                };
                context.Headlines.Add(headLine);
            }
            if (headLine.Articles.All(x => x.Title != article.Title))
            {
                context.Articles.Add(article);
               
            }
        }

        public virtual int Save()
        {
            return _uow.Save();
        }


    }
}
