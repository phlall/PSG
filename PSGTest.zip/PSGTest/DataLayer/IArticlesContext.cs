﻿namespace PSGTest.DataLayer
{
    public interface IArticlesContext : IContext
    {
    }
}