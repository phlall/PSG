﻿using System;
using PSGTest.Models;

namespace PSGTest.DataLayer
{
    public interface IArticleRepository: IDisposable
    {
        void Insert(Article article);

        int Save();
    }
}