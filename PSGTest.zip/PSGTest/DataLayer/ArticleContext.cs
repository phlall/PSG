﻿using System.Data.Entity;
using PSGTest.Models;

namespace PSGTest.DataLayer
{
    public class ArticleContext : BaseContext<ArticleContext>, IContext
    {
        public DbSet<Article> Articles { get; set; }

        public DbSet<Headline> Headlines { get; set; }
       
    }
}