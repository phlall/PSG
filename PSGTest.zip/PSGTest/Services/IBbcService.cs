﻿using System.Threading.Tasks;

namespace PSGTest.Services
{
    public interface IBbcService
    {
        Task<T> GetArticles<T>();
    }
}
