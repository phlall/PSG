﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PSGTest.Helpers;

namespace PSGTest.Services
{
    public class BbcService : IBbcService
    {
        private readonly IServiceSettings _serviceSettings;

        public BbcService(IServiceSettings serviceSettings)
        {
            _serviceSettings = serviceSettings;
        }

        public async Task<T> GetArticles<T>()
        {
            T returnValue = default(T);
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(_serviceSettings.RootUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync(_serviceSettings.GetFullUrl());
                    response.EnsureSuccessStatusCode();
                    returnValue = JsonConvert.DeserializeObject<T>(((HttpResponseMessage)response).Content.ReadAsStringAsync().Result);
                }
                return returnValue;
            }
            catch (Exception e)
            {
                throw (e);
            }
        }
    }
}