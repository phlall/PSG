﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PSGTest.Models
{
    public class Headline
    {
        [Key]
        public Guid Id { get; set; }
        
        public string Source { get; set; }

        public string RequesterName { get; set; }

        public List<Article> Articles { get; set; }
    }
}