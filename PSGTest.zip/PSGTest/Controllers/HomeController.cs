﻿using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using PSGTest.DataLayer;
using PSGTest.Models;
using PSGTest.Services;

namespace PSGTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBbcService _bbcService;
        private readonly IArticleRepository _articleRepo;

        public HomeController(IBbcService bbcService, IArticleRepository articleRepo)
        {
            _articleRepo = articleRepo;
            _bbcService = bbcService;
        }
   
        public async Task<ActionResult> Index(Guid? newsRequestId)
        {
            ViewBag.Message = "Your news articles.";
            var headlines = await _bbcService.GetArticles<Headline>();
            // From login...
            headlines.RequesterName = "Colin Loggedin";
            headlines.Id = newsRequestId ?? Guid.NewGuid();
            return View(headlines);

        }

        public ActionResult SaveArticle(Article article)
        {
            _articleRepo.Insert(article);
            _articleRepo.Save();
           return RedirectToAction("Index", new { NewsRequestId = article.HeadLineId });
        }
    }
}