﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Ninject;
using PSGTest.DataLayer;
using PSGTest.Helpers;
using PSGTest.Services;

namespace PSGTest.Infrastructure
{
    public class NinjectDependencyResolver : IDependencyResolver
    {
        private readonly IKernel kernel;

        public NinjectDependencyResolver()
        {
            kernel = new StandardKernel();
            AddBindings();
        }

        public object GetService(Type serviceType)
        {
            return kernel.TryGet(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return kernel.GetAll(serviceType);
        }

        private void AddBindings()
        {
           kernel.Bind<IBbcService>().To<BbcService>();
            kernel.Bind<IServiceSettings>().To<ServiceSettings>();
            kernel.Bind<IArticleRepository>().To<ArticleRepository>();
            kernel.Bind<IUnitOfWork>().To<UnitOfWork<ArticleContext>>();
        }
    }
}