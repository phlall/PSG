﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PSGTest.Startup))]
namespace PSGTest
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
