namespace PSGTest.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Articles",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Author = c.String(),
                        Title = c.String(),
                        Description = c.String(),
                        Url = c.String(),
                        UrlToImage = c.String(),
                        PublishedAt = c.String(),
                        HeadLineId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Headlines", t => t.HeadLineId, cascadeDelete: true)
                .Index(t => t.HeadLineId);
            
            CreateTable(
                "dbo.Headlines",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Source = c.String(),
                        RequesterName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Articles", "HeadLineId", "dbo.Headlines");
            DropIndex("dbo.Articles", new[] { "HeadLineId" });
            DropTable("dbo.Headlines");
            DropTable("dbo.Articles");
        }
    }
}
