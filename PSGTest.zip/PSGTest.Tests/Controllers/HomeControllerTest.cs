﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PSGTest;
using PSGTest.Controllers;
using PSGTest.DataLayer;
using PSGTest.Helpers;
using PSGTest.Models;
using PSGTest.Services;

namespace PSGTest.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public async Task Index()
        {
            IUnitOfWork uow = new UnitOfWork<ArticleContext>();
            var bbcService = new BbcService(new ServiceSettings());
            var aritcleRepo = new ArticleRepository(uow);
            
            // Arrange
            HomeController controller = new HomeController(bbcService, aritcleRepo);

            // Act
            var result = await controller.Index(null) as ViewResult;
            if (result != null)
            {
                var model = result.Model as Headline;

                // Assert
                Assert.IsNotNull(result);
                Assert.IsTrue(model != null && model.Articles.Any());
            }
            else
            {
                Assert.Fail();
            }
            
        }

    }
}
