﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PSGTest.Helpers;
using PSGTest.Models;
using PSGTest.Services;

namespace PSGTest.Tests.ServiceTests
{
  
    [TestClass]
    public class BbcServiceTests
    {
        protected IServiceSettings ServiceSettings;
        protected IBbcService BbcService;

        [TestMethod]
        public async Task CanRetrieveNewsArticles()
        {
            ServiceSettings = new ServiceSettings();
            BbcService = new BbcService(ServiceSettings);
            var result = await BbcService.GetArticles<Headline>();

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Articles.Any());
        }

      
    }
}
